/**
  **********************************************************************************
  * I2C DRIVER - DIGILOG CONSOLE
  **********************************************************************************
  * @file i2c_driver.c
  * @brief Sets up and manages traffic on the four I2C busses. Polls the MCP23017
  *        GPIO expanders at a fixed rate and provides the CV streams
  *        to MCP4728 DACs at a fixed rate.
  *
  * The bucket controller has four identical I2C busses, one for each channel it controls.
  * Each of these I2C busses contains 3 MCP23017s (0x20, 0x21, 0x22) and 5 MCP4728s
  * (0x60, 0x61, 0x62, 0x63, 0x64). The first two MCP23017s are connected to the rotation pins
  * of the rotary encoders on their respective channel are polled at a higher rate (1,500 times/sec)
  * than the third one (only 100 times/sec, every superframe), which is only connected to push buttons.
  * The MCP4728s are fed a 12-bit, low speed 600Hz sample rate stream and provide 20 control
  * voltage DAC channels per console channel. I2C busses run at fast rate (400kHz).
  *
  * @author Skylar Denno (denno.o@northeastern.edu)
  * @date 2026-08-23
  * @version 1.0
  *
  * @attention
  *  Copyright (C) 2026 Skylar Denno
  *
  *  MIT License:
  *  Permission is hereby granted, free of charge, to any person obtaining a copy
  *  of this software and associated documentation files (the “Software”), to deal
  *  in the Software without restriction, including without limitation the rights
  *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
  *  of the Software, and to permit persons to whom the Software is furnished to do so,
  *  subject to the following conditions:
  *
  *  The above copyright notice and this permission notice shall be included in all
  *  copies or substantial portions of the Software.
  *  THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
  *  INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
  *  PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
  *  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
  *  CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
  *  OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
  **********************************************************************************
*/

#include "hardware_drivers/i2c_driver.h"
#include "stm32g474xx.h"
#include "stm32g4xx_ll_i2c.h"
#include "system_stm32g4xx.h"
#include <stdbool.h>
#include "CONFIG.h"
#include <stdio.h>
#include "FreeRTOS.h"
#include "task.h"

#define TRANSFER_US(n) (((((n) + 1) * 9 + 3) * 5) / 2) // transfer time in microseconds for any number of bytes
#define BUDGET_LIMIT ((I2C_SLOT_PERIOD_US * 92) / 100) // max time budget during send frame.
static uint32_t timeout_cycles;


/*=============================== CHANNEL <-> BUS MAPPING ================================*/
/* Which bus (CONFIG.h) and which pins (CubeMX labels, for bit-banging) serve each console channel.
   Keep the pin labels in step with the bus chosen in CONFIG.h */

const channel_i2c_hw_t channel_i2c_hw[CHANNELS] = {
    {CHANNEL0_I2C_BUS, I2C1_Clock_GPIO_Port, I2C1_Clock_Pin, I2C1_Data_GPIO_Port, I2C1_Data_Pin, CHANNEL0_I2C_AF},
    {CHANNEL1_I2C_BUS, I2C2_Clock_GPIO_Port, I2C2_Clock_Pin, I2C2_Data_GPIO_Port, I2C2_Data_Pin, CHANNEL1_I2C_AF},
    {CHANNEL2_I2C_BUS, I2C3_Clock_GPIO_Port, I2C3_Clock_Pin, I2C3_Data_GPIO_Port, I2C3_Data_Pin, CHANNEL2_I2C_AF},
    {CHANNEL3_I2C_BUS, I2C4_Clock_GPIO_Port, I2C4_Clock_Pin, I2C4_Data_GPIO_Port, I2C4_Data_Pin, CHANNEL3_I2C_AF},
};

I2C_TypeDef *i2c_channel_bus (uint8_t channel)
{
    return channel_i2c_hw[channel].bus;
}

uint8_t i2c_bus_index (I2C_TypeDef *bus)
{
    for (uint8_t i = 0; i < CHANNELS; i++)
    {
        if (channel_i2c_hw[i].bus == bus) return i;
    }
    return CHANNELS; // indicate failure
}

volatile uint32_t i2c_fail_isr[CHANNELS];  // ISR register when the last transfer failed
volatile uint8_t  i2c_fail_step[CHANNELS]; // 1 busy before start, 2 data, 3 waiting for STOP, 4 NACK at end

static inline void note_fail (I2C_TypeDef *bus, uint8_t step)
{
    const uint8_t i = i2c_bus_index(bus);
    if (i < CHANNELS) { i2c_fail_isr[i] = bus->ISR; i2c_fail_step[i] = step; }
}


/*=============================== LOW LEVEL HELPERS ================================*/

/**
 ----------------------------------------------------------------------------------
  @brief INTERNAL wait_flag : bus, flag, abort on negative acknoledge?, microseconds -> bool
  Polls the I2C status register until transfer suceeds or fails 
 ----------------------------------------------------------------------------------
*/
static bool wait_flag (I2C_TypeDef *bus, uint32_t flag, bool abort_on_nack)
{
    const uint32_t time0 = DWT->CYCCNT;
    uint32_t spins = 0;

    for (;;)
    {
        const bool timed_out = (DWT->CYCCNT - time0) > timeout_cycles;
        const uint32_t isr = bus->ISR;

        if (isr & flag) return true;
        if (abort_on_nack && (isr & I2C_ISR_NACKF)) return false;
        if (isr & (I2C_ISR_BERR | I2C_ISR_ARLO)) return false;
        if (timed_out) return false;

        if ((++spins & 0xFF) == 0 && xTaskGetSchedulerState() == taskSCHEDULER_RUNNING)
        {
            taskYIELD();
        }
    }
}


/**
 ----------------------------------------------------------------------------------
  @brief INTERNAL clear_flags : bus -> Void
  Clears flags on a bus
 ----------------------------------------------------------------------------------
*/
static inline void clear_flags (I2C_TypeDef *bus)
{
    bus->ICR = I2C_ICR_STOPCF | I2C_ICR_NACKCF | I2C_ICR_BERRCF | I2C_ICR_ARLOCF | I2C_ICR_OVRCF;
}


/**
 ----------------------------------------------------------------------------------
  @brief INTERNAL bus_idle : bus, microseconds -> bool
  Clears stale flags and confirms the bus is actually free (idle) before starting
 ----------------------------------------------------------------------------------
*/
static bool bus_idle (I2C_TypeDef *bus)
{
    clear_flags(bus);
    return !(bus->ISR & I2C_ISR_BUSY);
}

/**
 ----------------------------------------------------------------------------------
  @brief INTERNAL abort_transfer : bus -> void
  Aborts transfer
 ----------------------------------------------------------------------------------
*/
static void abort_transfer (I2C_TypeDef *bus)
{
    bus->ISR = I2C_ISR_TXE; // flush TXDR
    clear_flags(bus);

    if (bus->ISR & I2C_ISR_BUSY)
    {
        bus->CR2 |= I2C_CR2_STOP;
        // uint32_t t0 = DWT->CYCCNT;
        /*while ((bus->ISR & I2C_ISR_BUSY) && (DWT->CYCCNT - t0) < timeout_cycles)
        {
        }*/
        if (bus->ISR & I2C_ISR_BUSY)
        {
            LL_I2C_Disable(bus);
            (void)bus->CR1;
            LL_I2C_Enable(bus);
        }
    }
    clear_flags(bus);
}


/*=============================== PUBLIC I2C FUNCTIONS ================================*/
/* Higher-level functions to interact with I2C */


/**
 ----------------------------------------------------------------------------------
  @brief PUBLIC i2c_init : Initialize the i2c busses, call on I2C1 ... I2C4
 ----------------------------------------------------------------------------------
*/
void i2c_init (void)
{
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    if (!(DWT->CTRL & DWT_CTRL_CYCCNTENA_Msk))
    {
        DWT->CYCCNT = 0;
        DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
    }
    timeout_cycles = (uint64_t)(((uint64_t)TIMEOUT_US * (uint64_t)SystemCoreClock) / 1000000U);
    printf("\r\n    timeout_cycles=%lu", timeout_cycles);
}


/**
 ----------------------------------------------------------------------------------
  @brief PUBLIC i2c_read : I2C bus (I2C1 ... I2C4 = I2C_TypeDef), chip address 
                       data pointer, number of bytes to write -> bool
  Read (blocking)
 ----------------------------------------------------------------------------------
*/
bool i2c_read (I2C_TypeDef *bus, uint8_t addr, uint8_t *data, uint8_t nbytes)
{
    if (nbytes > I2C_MAX_TRANSFER_LEN || (nbytes && !data) || nbytes == 0) return false;
    if (!bus_idle(bus)) // idle timeout 1000us
    {
        note_fail(bus, 1);
        abort_transfer(bus);
        return false;
    } // bus is idle

    // head of the read block
    LL_I2C_HandleTransfer(
        bus,
        (uint32_t)(addr << 1), // chip address (shift 1 to put 8 bit type into right place for 7 bit addr)
        LL_I2C_ADDRSLAVE_7BIT,
        nbytes,
        LL_I2C_MODE_AUTOEND,
        LL_I2C_GENERATE_START_READ
    );

    // read the content and save at *data
    for (uint8_t i = 0; i < nbytes; i++)
    {
        if (!wait_flag(bus, I2C_ISR_RXNE, true))
        {
            note_fail(bus, 2);
            abort_transfer(bus);
            return false;
        }
        data[i] = (uint8_t)bus->RXDR;
    }


    if (!wait_flag(bus, I2C_ISR_STOPF, false))
    {
        note_fail(bus, 3);
        abort_transfer(bus);
        return false;
    }

    if (bus->ISR & I2C_ISR_NACKF)
    {
        note_fail(bus, 4);
        abort_transfer(bus);
        return false;
    }

    clear_flags(bus);
    return true;
}


/**
 ----------------------------------------------------------------------------------
  @brief PUBLIC i2c_write : I2C bus (I2C1 ... I2C4 = I2C_TypeDef), chip address 
                       data pointer, number of bytes to write -> bool
  Write (blocking)
 ----------------------------------------------------------------------------------
*/
bool i2c_write (I2C_TypeDef *bus, uint8_t addr, const uint8_t *data, uint8_t nbytes)
{
    if (nbytes > I2C_MAX_TRANSFER_LEN || (nbytes && !data)) return false;
    if (!bus_idle(bus)) // idle timeout 1000us
    {
        abort_transfer(bus);
        return false;
    } // bus is idle

    // head of the message
    LL_I2C_HandleTransfer(
        bus,
        (uint32_t)(addr << 1), // chip address (shift 1 to put 8 bit type into right place for 7 bit addr)
        LL_I2C_ADDRSLAVE_7BIT,
        nbytes,
        LL_I2C_MODE_AUTOEND,
        LL_I2C_GENERATE_START_WRITE
    );

    // send the content of the message
    for (uint8_t i = 0; i < nbytes; i++)
    {
        if (!wait_flag(bus, I2C_ISR_TXIS, true))
        {
            abort_transfer(bus);
            return false;
        }
        bus->TXDR = data[i];
    }

    if (!wait_flag(bus, I2C_ISR_STOPF, false))
    {
        abort_transfer(bus);
        return false;
    }

    if (bus->ISR & I2C_ISR_NACKF)
    {
        abort_transfer(bus);
        return false;
    }

    clear_flags(bus);
    return true;
}


/**
 ----------------------------------------------------------------------------------
  @brief PUBLIC i2c_probe : I2C bus (I2C1 ... I2C4 = I2C_TypeDef), chip address -> bool
  Returns whether a specific I2C chip is free or not
 ----------------------------------------------------------------------------------
*/
bool i2c_probe (I2C_TypeDef *bus, uint8_t addr)
{
    uint8_t dummy[2];
    return i2c_read(bus, addr, dummy, 2);
}


/**
 ----------------------------------------------------------------------------------
  @brief PUBLIC i2c_probeall : void --> void
  (Developer mode) probes all the i2c busses with uart messages
 ----------------------------------------------------------------------------------
*/
void i2c_probeall (void)
{
    for (uint8_t b = 0; b < CHANNELS; b++)
    {
        for (uint8_t a = 0; a < sizeof(MCP23017_ADDRS); a++)
        {
            bool succ = i2c_probe(i2c_channel_bus(b), MCP23017_ADDRS[a]);
            printf("\r\n    Probing 0x%x @ I2C %d %s\r", MCP23017_ADDRS[a], b + 1, succ ? "GOOD" : "FAILED or not present");
        }

        for (uint8_t a = 0; a < sizeof(MCP4728_ADDRS); a++)
        {
            bool succ = i2c_probe(i2c_channel_bus(b), MCP4728_ADDRS[a]);
            printf("\r\n    Probing 0x%x @ I2C %d %s\r", MCP4728_ADDRS[a], b + 1, succ ? "GOOD" : "FAILED or not present");
        }

        printf("\r\n");
    }
}


void bb_claim (GPIO_TypeDef *scl_port, uint32_t scl_pin, GPIO_TypeDef *sda_port, uint32_t sda_pin)
{
    GPIO_InitTypeDef g = {0};
    g.Mode = GPIO_MODE_OUTPUT_OD;
    g.Pull = GPIO_NOPULL;
    g.Speed = GPIO_SPEED_FREQ_HIGH;

    scl_port->BSRR = scl_pin;
    sda_port->BSRR = sda_pin;

    g.Pin = scl_pin;
    HAL_GPIO_Init(scl_port, &g);
    g.Pin = sda_pin;
    HAL_GPIO_Init(sda_port, &g);
}


void bb_release (GPIO_TypeDef *scl_port, uint32_t scl_pin, GPIO_TypeDef *sda_port, uint32_t sda_pin, uint8_t af)
{
    GPIO_InitTypeDef g = {0};
    g.Mode = GPIO_MODE_AF_OD;
    g.Pull = GPIO_NOPULL;
    g.Speed = GPIO_SPEED_FREQ_HIGH;
    g.Alternate = af;

    g.Pin = scl_pin;
    HAL_GPIO_Init(scl_port, &g);
    g.Pin = sda_pin;
    HAL_GPIO_Init(sda_port, &g);
}


void i2c_channel_bb_claim (uint8_t channel)
{
    const channel_i2c_hw_t *hw = &channel_i2c_hw[channel];
    bb_claim(hw->scl_port, hw->scl_pin, hw->sda_port, hw->sda_pin);
}


void i2c_channel_bb_release (uint8_t channel)
{
    const channel_i2c_hw_t *hw = &channel_i2c_hw[channel];
    bb_release(hw->scl_port, hw->scl_pin, hw->sda_port, hw->sda_pin, hw->af);
}
