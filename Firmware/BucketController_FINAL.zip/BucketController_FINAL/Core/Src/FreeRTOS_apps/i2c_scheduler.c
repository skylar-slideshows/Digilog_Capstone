#include "CONFIG.h"

#include "FreeRTOS.h"
#include "control_integration/control_interface.h"
#include "task.h"
#include "cmsis_os2.h"
#include "hardware_drivers/i2c_driver.h"
#include "hardware_drivers/mcp23017.h"
#include "hardware_drivers/mcp4728_cache.h"
#include "portmacro.h"
#include "projdefs.h"
#include "stm32g474xx.h"
#include "stm32g4xx_hal.h"
#include <stdbool.h>
#include <string.h>

#ifdef DEVELOPER_MODE

#include <stdio.h>

#endif

#define MCP23017S_PER_CHANNEL sizeof(MCP23017_ADDRS) / sizeof(MCP23017_ADDRS[0])

#define MCP23017_1_ADDR MCP23017_ADDRS[0]
#define MCP23017_2_ADDR MCP23017_ADDRS[1]
#define MCP23017_BUTTON_ADDR MCP23017_ADDRS[2]
#define MCP23017_FRAMES_UNTIL_RETRY 2000

#define MCP4728S_PER_CHANNEL sizeof(MCP4728_ADDRS) / sizeof(MCP4728_ADDRS[0])

#define MCP4728S_PER_FRAME 2
#define MCP4728_CALLS_UNTIL_RETRY 800
#define MCP4728_CALLS_UNTIL_REFRESH 60 // rewrite an unchanged DAC every 100ms in case it was reset/replugged

#define SUPERFRAME_SIZE 15


typedef struct
{
    uint8_t frame_counter;
    uint8_t last_written_mcp4728_idx;

    uint16_t mcp4728_fail_retry_counter[MCP4728S_PER_CHANNEL]; //!< Countdown until we retry polling after fails an i2c call
    uint8_t mcp4728_refresh_counter[MCP4728S_PER_CHANNEL];     //!< Countdown until we rewrite a DAC even if its cache is unchanged

    uint16_t mcp23017_retry_counter[MCP23017S_PER_CHANNEL]; //!< Countdown until we retry polling after a GPIO expander fails an i2c call

    bool mcp23017_seen[MCP23017S_PER_CHANNEL]; //!< Has answered at least once, so a failure is worth reporting
    bool mcp4728_seen[MCP4728S_PER_CHANNEL];

    uint8_t mcp23017_fail_streak[MCP23017S_PER_CHANNEL]; //!< Consecutive failures from a chip that is plugged in
    uint8_t mcp4728_fail_streak[MCP4728S_PER_CHANNEL];
} i2c_scheduler_state_t;


static const i2c_scheduler_state_t default_scheduler_state = {
    .frame_counter = 0,
    .last_written_mcp4728_idx = 0,
    .mcp4728_fail_retry_counter = {0},
    .mcp4728_refresh_counter = {0},
    .mcp23017_retry_counter = {0} //
};

static i2c_scheduler_state_t scheduler_states[CHANNELS] = {default_scheduler_state};



#define FAILS_BEFORE_BACKOFF 20 // consecutive failures before a present chip is treated as gone

static inline void mcp23017_poll_maybe (I2C_TypeDef *bus, uint8_t addr, uint16_t *retry_counter,
                                        uint16_t frames_until_retry, bool *seen, uint8_t *fail_streak)
{
    if (*retry_counter > 0)
    {
        *retry_counter = *retry_counter - 1;
        return;
    }

    if (mcp23017_poll_to_cache(bus, addr))
    {
        *seen = true;
        *fail_streak = 0;
        return;
    }

#if DEVELOPER_MODE
    if (*seen)
    {
        const uint8_t b = i2c_bus_index(bus);
        printf("\r\n%lu ms  I2C%u expander 0x%02X failed  step %u  ISR 0x%08lX  streak %u\n",
               (unsigned long)HAL_GetTick(), b + 1, addr, i2c_fail_step[b],
               (unsigned long)i2c_fail_isr[b], *fail_streak + 1);
    }
#endif

    // 
    if (*seen && ++(*fail_streak) < FAILS_BEFORE_BACKOFF) return;

    *fail_streak = 0;
    *retry_counter = frames_until_retry;
}


static void read_mcp23017s (uint8_t channel)
{
    i2c_scheduler_state_t *state = &(scheduler_states[channel]);
    I2C_TypeDef *i2c_bus = i2c_channel_bus(channel);

    mcp23017_poll_maybe(
        i2c_bus,
        MCP23017_1_ADDR,
        &(state->mcp23017_retry_counter[0]),
        MCP23017_FRAMES_UNTIL_RETRY,
        &(state->mcp23017_seen[0]),
        &(state->mcp23017_fail_streak[0])
    );
    mcp23017_poll_maybe(
        i2c_bus,
        MCP23017_2_ADDR,
        &(state->mcp23017_retry_counter[1]),
        MCP23017_FRAMES_UNTIL_RETRY,
        &(state->mcp23017_seen[1]),
        &(state->mcp23017_fail_streak[1])
    );
    if (state->frame_counter == SUPERFRAME_SIZE - 1)
    {
        mcp23017_poll_maybe(
            i2c_bus,
            MCP23017_BUTTON_ADDR,
            &(state->mcp23017_retry_counter[2]),
            MCP23017_FRAMES_UNTIL_RETRY / SUPERFRAME_SIZE,
            &(state->mcp23017_seen[2]),
            &(state->mcp23017_fail_streak[2])
        );
    }
}

static inline void mcp4728_flush_maybe (
    I2C_TypeDef *bus,
    uint8_t addr,
    uint16_t *retry_counter,
    uint16_t frames_until_retry,
    uint8_t *refresh_counter,
    bool *seen,
    uint8_t *fail_streak
)
{
    if (*retry_counter > 0)
    {
        *retry_counter = *retry_counter - 1;
        return;
    }
    // DAC writes are most of the bus time, so skip chips whose outputs haven't changed
    if (mcp4728_cache_is_synced(bus, addr) && *refresh_counter > 0)
    {
        *refresh_counter = *refresh_counter - 1;
        return;
    }
    *refresh_counter = MCP4728_CALLS_UNTIL_REFRESH;

    const uint8_t code = mcp4728_cache_flush_fastWrite(bus, addr);
    if (code == 0)
    {
        *seen = true;
        *fail_streak = 0;
        return;
    }

#if DEVELOPER_MODE
    if (*seen)
    {
        const uint8_t b = i2c_bus_index(bus);
        printf("\r\n%lu ms  I2C%u DAC 0x%02X failed  step %u  ISR 0x%08lX  streak %u\n",
               (unsigned long)HAL_GetTick(), b + 1, addr, i2c_fail_step[b],
               (unsigned long)i2c_fail_isr[b], *fail_streak + 1);
    }
#endif

    if (*seen && ++(*fail_streak) < FAILS_BEFORE_BACKOFF) return;

    *fail_streak = 0;
    *retry_counter = frames_until_retry;
}

static void write_mcp4728s (uint8_t channel)
{
    i2c_scheduler_state_t *state = &(scheduler_states[channel]);
    I2C_TypeDef *i2c_bus = i2c_channel_bus(channel);

    for (uint8_t i = 0; i < MCP4728S_PER_FRAME; i++)
    {
        mcp4728_flush_maybe(
            i2c_bus,
            MCP4728_ADDRS[state->last_written_mcp4728_idx],
            &(state->mcp4728_fail_retry_counter[state->last_written_mcp4728_idx]),
            MCP4728_CALLS_UNTIL_RETRY,
            &(state->mcp4728_refresh_counter[state->last_written_mcp4728_idx]),
            &(state->mcp4728_seen[state->last_written_mcp4728_idx]),
            &(state->mcp4728_fail_streak[state->last_written_mcp4728_idx])
        );
        state->last_written_mcp4728_idx = (state->last_written_mcp4728_idx + 1) % MCP4728S_PER_CHANNEL;
    }
}

static void start_i2c_frame (uint8_t channel)
{
    read_mcp23017s(channel);
    update_control_values(channel);
    //update_control_leds(channel);
    // TODO: DAC values
    write_mcp4728s(channel);
    scheduler_states[channel].frame_counter = (scheduler_states[channel].frame_counter + 1) % SUPERFRAME_SIZE;
}

static void i2c_scheduler_task (void *arg)
{
    uint8_t channel = *(uint8_t *)arg;

    for (;;)
    {
        //uint32_t t0 = DWT->CYCCNT;
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
        start_i2c_frame(channel);
        //uint32_t t1 = DWT->CYCCNT;
        //printf("\r\n%d us\n", (t1 - t0) / 170);
    }
}

static osThreadId_t i2c_scheduler_task_handles[4] = {NULL, NULL, NULL, NULL};
static uint8_t i2c_sched_task_args[4];

static uint32_t I2CSchedulerBuffers[4][512];
static StaticTask_t I2CSchedulerControlBlocks[4];

extern TIM_HandleTypeDef htim4; // from main.c

void init_i2c_scheduler (void)
{
    const char *names[4] = {
        "i2cscheduler1",
        "i2cscheduler2",
        "i2cscheduler3",
        "i2cscheduler4",
    };

    for (uint8_t i = 0; i < CHANNELS; i++)
    {
        const osThreadAttr_t attr = {
            .name = names[i],
            .stack_mem = I2CSchedulerBuffers[i],
            .stack_size = sizeof(I2CSchedulerBuffers[i]),
            .cb_mem = &(I2CSchedulerControlBlocks[i]),
            .cb_size = sizeof(I2CSchedulerControlBlocks[i]),
            .priority = osPriorityBelowNormal,
        };
        i2c_sched_task_args[i] = i;
        i2c_scheduler_task_handles[i] = osThreadNew(i2c_scheduler_task, &(i2c_sched_task_args[i]), &attr);
    }

    HAL_NVIC_SetPriority(TIM4_IRQn, 6, 0);
    HAL_NVIC_EnableIRQ(TIM4_IRQn);
    HAL_TIM_Base_Start_IT(&htim4);
}

void i2c_scheduler_trigger_frame (void)
{
    BaseType_t enabled = 0;

    for (uint8_t i = 0; i < CHANNELS; i++)
    {
        if (i2c_scheduler_task_handles[i] == NULL)
        {
            continue;
        }
        vTaskNotifyGiveFromISR(i2c_scheduler_task_handles[i], &enabled);
    }

    portYIELD_FROM_ISR(enabled);
}